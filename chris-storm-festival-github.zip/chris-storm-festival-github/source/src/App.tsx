import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Award, CalendarDays, Check, ChevronDown, Clock3, ExternalLink, Film, Globe2, Instagram, Mail, Menu, Send, ShieldCheck, X } from 'lucide-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

type Lang = 'en' | 'de';
type PhaseKey = 'opening' | 'regular' | 'late' | 'notification' | 'event';

const dates: Record<PhaseKey, Date> = {
  opening: new Date('2026-09-01T00:00:00+02:00'),
  regular: new Date('2026-10-31T23:59:59+01:00'),
  late: new Date('2026-11-27T23:59:59+01:00'),
  notification: new Date('2026-11-28T00:00:00+01:00'),
  event: new Date('2026-12-18T00:00:00+01:00'),
};

const dateLabels: Record<Lang, Record<PhaseKey, string>> = {
  en: { opening: 'Opening date', regular: 'Regular deadline', late: 'Late deadline', notification: 'Notification date', event: 'Festival date' },
  de: { opening: 'Eröffnung', regular: 'Reguläre Deadline', late: 'Späte Deadline', notification: 'Benachrichtigung', event: 'Festivaltermin' },
};

const copy = {
  en: {
    nav: ['About', 'Submit', 'Rules', 'Awards', 'Contact'],
    eyebrow: 'Online Horror Short Film Festival',
    tag: 'HORROR FOR EVERYONE',
    lede: 'No big studios. No limits. Just independent horror.',
    howToSubmit: 'How to submit your film',
    submitSteps: [
      { number: '01', text: 'Upload your film to YouTube or Vimeo and keep it PUBLIC. You do not need to make it private or unlisted.' },
      { number: '02', text: 'Your film may already be publicly available online. This is completely fine.' },
      { number: '03', text: 'Copy the link and click SUBMIT YOUR FILM.' },
    ],
    submitNote: 'Full HD (1080p) recommended · Max. 30 minutes · Free submission (€0 / $0)',
    submit: 'Submit your film',
    dates: 'Dates & countdown',
    metaDate: 'Festival date',
    metaFormat: 'Format',
    metaFee: 'Entry fee',
    scroll: 'Enter the festival',
    online: 'Online festival',
    short: 'Short films · max. 30 min',
    international: 'International filmmakers',
    free: 'Free submission',
    aboutKicker: 'The first reel',
    aboutTitle: 'A night for the <em>unafraid.</em>',
    aboutIntro: '<strong>Chris Storm Independent Horror Festival – Vol. 1</strong> is a fully <strong>online horror short film festival</strong> for independent filmmakers from around the world.',
    aboutBody: 'We celebrate no-budget, low-budget and independent productions. What matters are ideas, atmosphere, storytelling and a personal cinematic vision.',
    manifesto: ['No budget. Low budget.', 'Original stories over polished formulas.', 'Independent horror from everywhere.'],
    countdownBefore: 'Countdown to',
    open: 'Submissions open',
    completed: 'Festival completed',
    passed: 'Past',
    now: 'Now',
    next: 'Next',
    phase: 'The status updates automatically. Green = current phase, red = passed, yellow = next upcoming date.',
    submissionKicker: 'Open call · Vol. 1',
    submissionTitle: 'Your nightmare.<br/><em>Your vision.</em>',
    submissionBody: 'Horror short films up to 30 minutes. Psychological, supernatural, found footage, creature, experimental, dark comedy and more.',
    welcome: 'Productions made with little or no budget are especially welcome. No premiere requirement.',
    jury: 'A <strong>three-person jury of film lovers</strong> will judge the selected films. <strong>Chris Storm</strong> is one of the three jury members.',
    rulesKicker: 'Read before you submit',
    rulesTitle: 'The fine <em>print.</em>',
    rulesSideTitle: 'Keep your rights.',
    rulesSide: 'A submission does not guarantee selection. Filmmakers retain ownership of their work.',
    contactKicker: 'Festival desk',
    contactTitle: 'Make some<br/><em>noise.</em>',
    contactBody: 'Festival news, updates and contact. The FilmFreeway page is currently being prepared.',
    modalTitle: 'Submit your film',
    modalIntro: 'Fill out the form and send us the public link to your film. Your film may already be publicly available online. Your details will be sent to the festival by email.',
    send: 'Send submission by email',
    sent: 'Your email draft is ready. Thank you for submitting.',
    synopsis: 'Short synopsis',
    filmLink: 'Film link (YouTube/Vimeo)',
    rights: 'I own the necessary rights and accept the festival terms.',
    publicHelp: 'Please provide a public YouTube or Vimeo link. Full HD (1080p) is recommended.',
    filmFreeway: 'Coming soon on FilmFreeway',
  },
  de: {
    nav: ['Über uns', 'Einreichen', 'Regeln', 'Awards', 'Kontakt'],
    eyebrow: 'Online Horror Kurzfilmfestival',
    tag: 'HORROR FÜR ALLE',
    lede: 'Keine großen Studios. Keine Grenzen. Nur unabhängiger Horror.',
    howToSubmit: 'So reichst du deinen Film ein',
    submitSteps: [
      { number: '01', text: 'Lade deinen Film auf YouTube oder Vimeo hoch und lasse ihn ÖFFENTLICH. Du musst ihn nicht privat oder nicht gelistet stellen.' },
      { number: '02', text: 'Dein Film darf bereits öffentlich online verfügbar sein. Das ist völlig in Ordnung.' },
      { number: '03', text: 'Kopiere den Link und klicke auf DEINEN FILM EINREICHEN.' },
    ],
    submitNote: 'Full HD (1080p) empfohlen · Max. 30 Minuten · Einreichung kostenlos (€0 / $0)',
    submit: 'Deinen Film einreichen',
    dates: 'Termine & Countdown',
    metaDate: 'Festivaltermin',
    metaFormat: 'Format',
    metaFee: 'Einreichungsgebühr',
    scroll: 'Festival betreten',
    online: 'Online-Festival',
    short: 'Kurzfilme · max. 30 Min.',
    international: 'Internationale Filmemacher',
    free: 'Kostenlose Einreichung',
    aboutKicker: 'Die erste Filmrolle',
    aboutTitle: 'Eine Nacht für die <em>Unerschrockenen.</em>',
    aboutIntro: '<strong>Chris Storm Independent Horror Festival – Vol. 1</strong> ist ein vollständig <strong>online stattfindendes Horror-Kurzfilmfestival</strong> für unabhängige Filmemacher aus aller Welt.',
    aboutBody: 'Wir feiern No-Budget-, Low-Budget- und Independent-Produktionen. Entscheidend sind Idee, Atmosphäre, Storytelling und die eigene filmische Vision.',
    manifesto: ['No Budget. Low Budget.', 'Eigene Geschichten statt polierter Formeln.', 'Unabhängiger Horror aus aller Welt.'],
    countdownBefore: 'Countdown bis',
    open: 'Einreichungen offen',
    completed: 'Festival beendet',
    passed: 'Vorbei',
    now: 'Jetzt',
    next: 'Als Nächstes',
    phase: 'Der Status aktualisiert sich automatisch. Grün = aktuelle Phase, Rot = vorbei, Gelb = nächster Termin.',
    submissionKicker: 'Open Call · Vol. 1',
    submissionTitle: 'Dein Albtraum.<br/><em>Deine Vision.</em>',
    submissionBody: 'Horror-Kurzfilme bis 30 Minuten. Psychologisch, übernatürlich, Found Footage, Creature, experimentell, Dark Comedy und mehr.',
    welcome: 'Produktionen mit kleinem oder keinem Budget sind ausdrücklich willkommen. Keine Premiere erforderlich.',
    jury: 'Eine <strong>dreiköpfige Jury aus Film-Liebhabern</strong> bewertet die ausgewählten Filme. <strong>Chris Storm</strong> ist eines der drei Jury-Mitglieder.',
    rulesKicker: 'Vor der Einreichung lesen',
    rulesTitle: 'Das <em>Kleingedruckte.</em>',
    rulesSideTitle: 'Behalte deine Rechte.',
    rulesSide: 'Eine Einreichung garantiert keine Auswahl. Filmemacher behalten ihre Rechte.',
    contactKicker: 'Festivalbüro',
    contactTitle: 'Mach ein bisschen<br/><em>Lärm.</em>',
    contactBody: 'Festival-News, Updates und Kontakt. Die FilmFreeway-Seite wird aktuell vorbereitet.',
    modalTitle: 'Film einreichen',
    modalIntro: 'Fülle das Formular aus und sende uns den öffentlichen Link zu deinem Film. Der Film darf bereits öffentlich online sein. Die Angaben werden per E-Mail an das Festival gesendet.',
    send: 'Einreichung per E-Mail senden',
    sent: 'Dein E-Mail-Entwurf ist bereit. Danke für deine Einreichung.',
    synopsis: 'Kurzbeschreibung',
    filmLink: 'Film-Link (YouTube/Vimeo)',
    rights: 'Ich besitze die erforderlichen Rechte und akzeptiere die Festivalbedingungen.',
    publicHelp: 'Bitte einen öffentlichen YouTube- oder Vimeo-Link angeben. Full HD (1080p) wird empfohlen.',
    filmFreeway: 'Demnächst auf FilmFreeway',
  },
};

function getPhase(now: Date) {
  if (now < dates.opening) return { current: null, next: 'opening' as PhaseKey };
  if (now < dates.regular) return { current: 'opening' as PhaseKey, next: 'regular' as PhaseKey };
  if (now < dates.late) return { current: 'late' as PhaseKey, next: 'notification' as PhaseKey };
  if (now < dates.notification) return { current: 'notification' as PhaseKey, next: 'event' as PhaseKey };
  if (now < dates.event) return { current: 'event' as PhaseKey, next: null };
  return { current: null, next: null };
}

function Home() {
  const [lang, setLang] = useState<Lang>('en');
  const [now, setNow] = useState(() => new Date());
  const [menuOpen, setMenuOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [sent, setSent] = useState(false);
  const t = copy[lang];
  const phase = useMemo(() => getPhase(now), [now]);
  const target = phase.next ? dates[phase.next] : null;
  const remaining = target ? Math.max(0, target.getTime() - now.getTime()) : 0;
  const time = {
    days: Math.floor(remaining / 86400000),
    hours: Math.floor(remaining / 3600000) % 24,
    minutes: Math.floor(remaining / 60000) % 60,
    seconds: Math.floor(remaining / 1000) % 60,
  };
  const pad = (value: number) => String(value).padStart(2, '0');
  const ids = ['about', 'submit', 'rules', 'awards', 'contact'];
  const features = [
    { icon: Film, title: lang === 'en' ? 'Horror short films' : 'Horror-Kurzfilme', body: lang === 'en' ? 'Psychological, supernatural, found footage, creature, experimental, dark comedy and more.' : 'Psychologischer, übernatürlicher, Found-Footage-, Creature-, Experimental- und Dark-Comedy-Horror.' },
    { icon: ShieldCheck, title: lang === 'en' ? 'No / low budget' : 'No-/Low-Budget', body: lang === 'en' ? 'Productions made with little or no budget are especially welcome.' : 'Produktionen mit kleinem oder keinem Budget sind ausdrücklich willkommen.' },
    { icon: Globe2, title: 'International', body: lang === 'en' ? 'Filmmakers from around the world.' : 'Filmemacher aus der ganzen Welt.' },
    { icon: Send, title: '€0.00', body: lang === 'en' ? 'Free submission for Vol. 1.' : 'Kostenlose Einreichung für Vol. 1.' },
  ];
  const awards = ['Best Horror Short', 'Best Director', 'Best No-Budget Film', 'Best Low-Budget Film', 'Most Original Nightmare', 'Audience Choice'];
  const rules = lang === 'en'
    ? ['Horror short films only; maximum 30 minutes including credits.', 'No-budget, low-budget and independent productions are welcome.', 'No premiere requirement.', 'Non-English films require English subtitles.', 'The submitter must hold the necessary rights.', 'Submission does not guarantee selection; filmmakers retain ownership.']
    : ['Nur Horror-Kurzfilme; maximal 30 Minuten inklusive Abspann.', 'No-Budget-, Low-Budget- und Independent-Produktionen sind willkommen.', 'Keine Premiere erforderlich.', 'Nicht-englische Filme benötigen englische Untertitel.', 'Der Einreicher muss die erforderlichen Rechte besitzen.', 'Eine Einreichung garantiert keine Auswahl; Filmemacher behalten ihre Rechte.'];

  useEffect(() => {
    const interval = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(interval);
  }, []);
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);
  useEffect(() => {
    document.body.style.overflow = modalOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [modalOpen]);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') setModalOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  useEffect(() => {
    const nodes = Array.from(document.querySelectorAll<HTMLElement>('.section, .fact-strip'));
    nodes.forEach((node) => node.classList.add('reveal-on-scroll'));
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };
  const submitForm = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const subject = encodeURIComponent(`Festival Submission – ${String(form.get('filmTitle') || '')}`);
    const body = encodeURIComponent(`Chris Storm Independent Horror Festival – Vol. 1

Film Title: ${form.get('filmTitle')}
Director / Filmmaker: ${form.get('director')}
Email: ${form.get('email')}
Country: ${form.get('country')}
Runtime: ${form.get('runtime')}
Genre: ${form.get('genre')}
Film Link: ${form.get('filmLink')}

Short Synopsis:
${form.get('description')}

Rights & Terms: Accepted`);
    window.location.href = `mailto:chrisstormfilms@gmail.com?subject=${subject}&body=${body}`;
    setSent(true);
  };

  return (
    <div className="festival-shell">
      <div className="film-effects" aria-hidden="true">
        <span className="film-scratch film-scratch-one" />
        <span className="film-scratch film-scratch-two" />
        <span className="film-scratch film-scratch-three" />
      </div>
      <header className="topbar">
        <div className="container topbar-inner">
          <a className="wordmark" href="#top" onClick={() => setMenuOpen(false)}>
            <span className="wordmark-reel">70MM / REEL 01</span>
            CHRIS STORM <strong>INDEPENDENT HORROR</strong><small>FESTIVAL · VOL. 1</small>
          </a>
          <nav className={`nav-links ${menuOpen ? 'open' : ''}`} aria-label="Main navigation">
            {t.nav.map((item, index) => <a key={item} href={`#${ids[index]}`} onClick={(event) => { event.preventDefault(); scrollTo(ids[index]); }}>{item}</a>)}
            <a className="nav-cta" href="#submit" onClick={(event) => { event.preventDefault(); setModalOpen(true); setMenuOpen(false); }}>{t.submit} <ExternalLink size={12} /></a>
          </nav>
          <button className="menu-toggle" onClick={() => setMenuOpen((value) => !value)} aria-label="Toggle navigation" aria-expanded={menuOpen}>{menuOpen ? <X /> : <Menu />}</button>
        </div>
      </header>

      <main id="top">
        <div className="language-float" aria-label="Language switcher">
          <span className="language-float-label">LANG</span>
          <button className={lang === 'de' ? 'active' : ''} onClick={() => setLang('de')} aria-label="Deutsch">DE</button>
          <button className={lang === 'en' ? 'active' : ''} onClick={() => setLang('en')} aria-label="English">EN</button>
        </div>
        <section className="hero">
          <div className="film-edge film-edge-left" aria-hidden="true" />
          <div className="film-edge film-edge-right" aria-hidden="true" />
          <div className="hero-frame-mark hero-frame-mark-left" aria-hidden="true">FRAME 0001</div>
          <div className="hero-frame-mark hero-frame-mark-right" aria-hidden="true">CSHF · 2026</div>
          <div className="container hero-inner">
            <div className="hero-copy">
              <div className="eyebrow">{t.eyebrow}</div>
              <h1>INDEPENDENT<span>HORROR</span></h1>
              <p className="hero-lede">{t.lede}</p>
              <div className="hero-submit-guide" aria-label={t.howToSubmit}>
                <div className="guide-heading">
                  <span>{t.howToSubmit}</span>
                  <span className="guide-rule" />
                </div>
                <div className="guide-steps">
                  {t.submitSteps.map((step) => (
                    <div className="guide-step" key={step.number}>
                      <b>{step.number}</b>
                      <p>{step.text}</p>
                    </div>
                  ))}
                </div>
                <div className="guide-note"><Clock3 size={13} /> {t.submitNote}</div>
              </div>
              <div className="hero-actions">
                <button className="button primary" onClick={() => setModalOpen(true)}>{t.submit} <Send size={14} /></button>
                <button className="button ghost" onClick={() => scrollTo('dates')}>{t.dates} <ChevronDown size={14} /></button>
              </div>
              <div className="hero-meta">
                <div>{t.metaDate}<strong>18.12.2026</strong></div>
                <div>{t.metaFormat}<strong>Online</strong></div>
                <div>{t.metaFee}<strong>€0.00</strong></div>
              </div>
            </div>
            <div className="poster-frame">
              <img src="/poster-art.png" alt="Chris Storm Independent Horror Festival poster artwork" />
              <div className="poster-stamp">VOL. 01 / 2026</div>
            </div>
          </div>
          <div className="scroll-note">{t.scroll}</div>
        </section>

        <section className="fact-strip" aria-label="Festival facts">
          <div className="container fact-grid">
            <div className="fact"><CalendarDays size={16} />18 DEC 2026<span>{t.online}</span></div>
            <div className="fact"><Film size={16} />SHORT FILMS<span>{t.short}</span></div>
            <div className="fact"><Globe2 size={16} />INTERNATIONAL<span>{t.international}</span></div>
            <div className="fact"><Check size={16} />€0.00<span>{t.free}</span></div>
            <div className="fact"><Award size={16} />AWARDS<span>RECOGNITION</span></div>
          </div>
        </section>

        <section className="section" id="dates">
          <div className="container">
            <div className="section-heading">
              <div><div className="section-kicker">2026 · Vol. 1</div><h2>{t.dates}</h2></div>
              <p>{t.phase}</p>
            </div>
            <div className="countdown-wrap" aria-live="polite">
              <div className="countdown-top">
                <div className="countdown-label">{target ? `${t.countdownBefore} ${dateLabels[lang][phase.next as PhaseKey]}` : t.completed}</div>
                <div className="countdown-target">{target ? target.toLocaleString(lang === 'de' ? 'de-DE' : 'en-US', { dateStyle: 'long', timeStyle: 'short' }) : '18 December 2026'}</div>
              </div>
              <div className="timer">
                <div className="timebox"><strong>{pad(time.days)}</strong><span>{lang === 'de' ? 'Tage' : 'Days'}</span></div>
                <div className="timebox"><strong>{pad(time.hours)}</strong><span>{lang === 'de' ? 'Stunden' : 'Hours'}</span></div>
                <div className="timebox"><strong>{pad(time.minutes)}</strong><span>{lang === 'de' ? 'Minuten' : 'Minutes'}</span></div>
                <div className="timebox"><strong>{pad(time.seconds)}</strong><span>{lang === 'de' ? 'Sekunden' : 'Seconds'}</span></div>
              </div>
            </div>
            <div className="timeline">
              {(Object.keys(dates) as PhaseKey[]).map((key) => {
                const status = phase.current === key ? 'current' : phase.next === key ? 'next' : dates[key] <= now ? 'past' : '';
                return <div key={key} className={`timeline-item ${status}`}><div className="timeline-date">{dates[key].toLocaleDateString(lang === 'de' ? 'de-DE' : 'en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</div><div className="timeline-name">{dateLabels[lang][key]}</div><div className={`status ${status}`}>{status === 'current' ? t.now : status === 'next' ? t.next : status === 'past' ? t.passed : '—'}</div></div>;
              })}
            </div>
          </div>
        </section>

        <section className="section dark-cut" id="about">
          <div className="container">
            <div className="section-heading"><div><div className="section-kicker">{t.aboutKicker}</div><h2 dangerouslySetInnerHTML={{ __html: t.aboutTitle }} /></div></div>
            <div className="about-grid">
              <div className="about-copy"><p dangerouslySetInnerHTML={{ __html: t.aboutIntro }} /><p>{t.aboutBody}</p><div className="pull-quote">NO BUDGET.<br />LOW BUDGET.<br />INDEPENDENT HORROR.</div></div>
              <div className="manifesto"><div className="manifesto-index"><span>CS / MANIFESTO</span><span>001—003</span></div><ul className="manifesto-list">{t.manifesto.map((line, index) => <li key={line}><b>0{index + 1}</b><span>{line}</span></li>)}</ul></div>
            </div>
          </div>
        </section>

        <section className="section" id="submit">
          <div className="container submission-layout">
            <div className="submission-intro"><div className="section-kicker">{t.submissionKicker}</div><h3 dangerouslySetInnerHTML={{ __html: t.submissionTitle }} /><p>{t.submissionBody}</p><p>{t.welcome}</p><div className="submission-note"><Clock3 size={15} />&nbsp; {lang === 'en' ? 'Full HD (1080p) recommended · Max. 30 minutes · Free submission (€0 / $0)' : 'Full HD (1080p) empfohlen · Max. 30 Minuten · Einreichung kostenlos (€0 / $0)'}</div><button className="button primary" onClick={() => setModalOpen(true)}>{t.submit} <Send size={14} /></button></div>
            <div className="feature-grid">{features.map(({ icon: Icon, title, body }) => <article className="feature-card" key={title}><Icon className="icon" size={21} /><h3>{title}</h3><p>{body}</p></article>)}</div>
          </div>
        </section>

        <section className="section dark-cut">
          <div className="container">
            <div className="section-heading"><div><div className="section-kicker">Selected films</div><h2>{lang === 'en' ? 'The jury' : 'Die Jury'}</h2></div><p dangerouslySetInnerHTML={{ __html: t.jury }} /></div>
            <div className="jury-line"><div className="jury-mark">JURY<br />03</div><p dangerouslySetInnerHTML={{ __html: t.jury }} /></div>
          </div>
        </section>

        <section className="section" id="awards">
          <div className="container"><div className="section-heading"><div><div className="section-kicker">Recognition</div><h2>{lang === 'en' ? 'Awards' : 'Awards'}</h2></div><p>{lang === 'en' ? 'Films will compete for a selection of festival awards.' : 'Die Filme treten um eine Auswahl an Festival-Awards an.'}</p></div><div className="awards-grid">{awards.map((award, index) => <article className="award" key={award}><span className="award-number">AWARD / 0{index + 1}</span><h3>{award}</h3></article>)}</div></div>
        </section>

        <section className="section dark-cut" id="rules">
          <div className="container rules-grid"><div><div className="section-kicker">{t.rulesKicker}</div><h2 className="section-heading" style={{ display: 'block', marginBottom: '20px' }} dangerouslySetInnerHTML={{ __html: t.rulesTitle }} /><ul className="rules-list">{rules.map((rule) => <li key={rule}>{rule}</li>)}</ul></div><aside className="rule-side"><ShieldCheck size={20} color="#dfb148" /><h3>{t.rulesSideTitle}</h3><p>{t.rulesSide}</p></aside></div>
        </section>

        <section className="section contact-section" id="contact">
          <div className="container contact-grid"><div><div className="section-kicker">{t.contactKicker}</div><h2 dangerouslySetInnerHTML={{ __html: t.contactTitle }} /><p>{t.contactBody}</p></div><div className="contact-links"><a className="contact-link" href="https://www.instagram.com/chris.storm_/?stkn=bXMxNjhuNnltZnZn&utm_source=qr" target="_blank" rel="noreferrer"><Instagram size={18} /><div><span>Instagram</span>@chris.storm_</div><ExternalLink size={14} /></a><a className="contact-link" href="mailto:chrisstormfilms@gmail.com"><Mail size={18} /><div><span>Email</span>chrisstormfilms@gmail.com</div><ExternalLink size={14} /></a><a className="contact-link" href="https://filmfreeway.com/" target="_blank" rel="noreferrer"><ExternalLink size={18} /><div><span>FilmFreeway</span>{t.filmFreeway}</div><ChevronDown size={14} /></a></div></div>
        </section>
      </main>

      <footer className="footer"><div className="container footer-inner"><div><strong>CHRIS STORM INDEPENDENT HORROR FESTIVAL · VOL. 1</strong><br />{lang === 'en' ? 'Independent filmmakers · Original stories · Real horror' : 'Unabhängige Filmemacher · Eigene Geschichten · Echter Horror'}</div><div className="footer-right">{lang === 'en' ? 'ONLINE · DECEMBER 18, 2026' : 'ONLINE · 18. DEZEMBER 2026'}<br />© {new Date().getFullYear()} Chris Storm</div></div></footer>

      {modalOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setModalOpen(false); }}><div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button className="close-modal" onClick={() => setModalOpen(false)} aria-label="Close"><X /></button><h2 id="modal-title">{t.modalTitle}</h2><p>{t.modalIntro}</p><div className="contact-mini"><div><span>Instagram</span><a href="https://www.instagram.com/chris.storm_/" target="_blank" rel="noreferrer">@chris.storm_</a></div><div><span>Email</span><a href="mailto:chrisstormfilms@gmail.com">chrisstormfilms@gmail.com</a></div></div><form className="submit-form" onSubmit={submitForm}><label htmlFor="filmTitle">{lang === 'en' ? 'Film title *' : 'Filmtitel *'}</label><input id="filmTitle" name="filmTitle" required /><label htmlFor="director">{lang === 'en' ? 'Director / filmmaker *' : 'Regisseur / Filmemacher *'}</label><input id="director" name="director" required /><label htmlFor="email">Email *</label><input id="email" name="email" type="email" required /><label htmlFor="country">{lang === 'en' ? 'Country *' : 'Land *'}</label><input id="country" name="country" required /><label htmlFor="runtime">{lang === 'en' ? 'Runtime *' : 'Laufzeit *'}</label><input id="runtime" name="runtime" placeholder="e.g. 12:34" required /><label htmlFor="genre">Genre</label><input id="genre" name="genre" placeholder="e.g. Psychological Horror" /><label htmlFor="filmLink">{t.filmLink} *</label><input id="filmLink" name="filmLink" type="url" placeholder="https://youtu.be/..." required /><div className="submit-help">{t.publicHelp}</div><label htmlFor="description">{t.synopsis}</label><textarea id="description" name="description" /><label className="check"><input type="checkbox" required /><span>{t.rights} *</span></label><button className="button primary" type="submit">{t.send} <Send size={14} /></button></form><div className="notice"><strong>{t.filmFreeway}</strong><br />{lang === 'en' ? 'The festival page is currently being prepared. As soon as the festival link is active, films can be submitted there directly.' : 'Der Festival-Account wird aktuell vorbereitet. Sobald der Festival-Link aktiv ist, kann dort direkt eingereicht werden.'}<br /><br /><a href="https://filmfreeway.com/" target="_blank" rel="noreferrer">FilmFreeway besuchen →</a></div>{sent && <div className="submit-success" role="status"><Check size={14} /> {t.sent}</div>}</div></div>}
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
